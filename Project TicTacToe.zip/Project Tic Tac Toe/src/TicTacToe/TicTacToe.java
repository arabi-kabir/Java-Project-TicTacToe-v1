package TicTacToe;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import org.omg.PortableServer.ID_ASSIGNMENT_POLICY_ID;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class TicTacToe {

	private JFrame frame;
	private String startGame = "X";
	private int xCount = 0;
	private int oCount = 0;
	
	private Color xColor = new Color(142, 68, 173);
	private Color yColor = new Color(51, 110, 123);
	private JButton btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
	private JTextField txtCountX;
	private JTextField txtCountO;

	
	String b1;
	String b2;
	String b3;
	String b4;
	String b5;
	String b6;
	String b7;
	String b8;
	String b9;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicTacToe window = new TicTacToe();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TicTacToe() {
		initialize();
	}
	
	private void gameScore(){
		txtCountX.setText(String.valueOf(xCount));
		txtCountO.setText(String.valueOf(oCount));
	}
	
	public void checkDraw(){
		if(b1.length() != 0 && b2.length() != 0 && b3.length() != 0 
		   && b4.length() != 0 && b5.length() != 0 && b6.length() != 0
		   && b7.length() != 0 && b8.length() != 0 && b9.length() != 0)
		{
			JOptionPane.showMessageDialog(frame, "Opps !! it's a draw. you both are stupid", " Game draw", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	
	
	private void refreshAll(){
		btn1.setText(null);
		btn2.setText(null);
		btn3.setText(null);
		btn4.setText(null);
		btn5.setText(null);
		btn6.setText(null);
		btn7.setText(null);
		btn8.setText(null);
		btn9.setText(null);
		
		btn1.setBackground(Color.LIGHT_GRAY);
		btn2.setBackground(Color.LIGHT_GRAY);
		btn3.setBackground(Color.LIGHT_GRAY);
		btn4.setBackground(Color.LIGHT_GRAY);
		btn5.setBackground(Color.LIGHT_GRAY);
		btn6.setBackground(Color.LIGHT_GRAY);
		btn7.setBackground(Color.LIGHT_GRAY);
		btn8.setBackground(Color.LIGHT_GRAY);
		btn9.setBackground(Color.LIGHT_GRAY);
		
		btn1.setEnabled(true);
		btn2.setEnabled(true);
		btn3.setEnabled(true);
		btn4.setEnabled(true);
		btn5.setEnabled(true);
		btn6.setEnabled(true);
		btn7.setEnabled(true);
		btn8.setEnabled(true);
		btn9.setEnabled(true);
	}
	
	private void choosePlayer(){
		if (startGame.equalsIgnoreCase("X")) {
			startGame = "O";
		}else {
			startGame = "X";
		}
	}

	
	private void winningGame() {
		 b1 = btn1.getText();
		 b2 = btn2.getText();
		 b3 = btn3.getText();
		 b4 = btn4.getText();
		 b5 = btn5.getText();
		 b6 = btn6.getText();
		 b7 = btn7.getText();
		 b8 = btn8.getText();
		 b9 = btn9.getText();
			
		// Core Logic 
		
		// For X
		if(b1==("X") && b2==("X") && b3==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b4==("X") && b5==("X") && b6==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b7==("X") && b8==("X") && b9==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b1==("X") && b4==("X") && b7==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b2==("X") && b5==("X") && b8==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b3==("X") && b6==("X") && b9==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b1==("X") && b5==("X") && b9==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		if(b3==("X") && b5==("X") && b7==("X")){
			JOptionPane.showMessageDialog(frame, "Player X wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			xCount++;
			gameScore();
			refreshAll();
		}
		
		// For O
		if(b1==("O") && b2==("O") && b3==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b4==("O") && b5==("O") && b6==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b7==("O") && b8==("O") && b9==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b1==("O") && b4==("O") && b7==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b2==("O") && b5==("O") && b8==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b3==("O") && b6==("O") && b9==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b1==("O") && b5==("O") && b9==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}
		if(b3==("O") && b5==("O") && b7==("O")){
			JOptionPane.showMessageDialog(frame, "Player O wins", "Tic Tac Toe Winner", JOptionPane.INFORMATION_MESSAGE);
			oCount++;
			gameScore();
			refreshAll();
		}		
		
		
		
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 800, 400);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(3, 5, 2, 2));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
	    btn1 = new JButton("");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn1.setBackground(xColor);
				}else {
					btn1.setBackground(yColor);
				}
				choosePlayer();
				btn1.setForeground(Color.WHITE);
				winningGame();
				btn1.setEnabled(false);
				//checkDraw();
			}
		});
		btn1.setBackground(Color.LIGHT_GRAY);
		btn1.setFocusable(false);
		btn1.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_1.add(btn1, BorderLayout.CENTER);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_2);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		btn2 = new JButton("");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn2.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn2.setBackground(xColor);
				}else {
					btn2.setBackground(yColor);
				}
				choosePlayer();
				btn2.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn2.setBackground(Color.LIGHT_GRAY);
		btn2.setFocusable(false);
		btn2.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_2.add(btn2, BorderLayout.CENTER);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_3);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		btn3 = new JButton("");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn3.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn3.setBackground(xColor);
				}else {
					btn3.setBackground(yColor);
				}
				choosePlayer();
				btn3.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn3.setBackground(Color.LIGHT_GRAY);
		btn3.setFocusable(false);
		btn3.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_3.add(btn3, BorderLayout.CENTER);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_4);
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel lblPlayerX = new JLabel("Player X Win");
		lblPlayerX.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlayerX.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel_4.add(lblPlayerX, BorderLayout.CENTER);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_5);
		panel_5.setLayout(new BorderLayout(0, 0));
		
		txtCountX = new JTextField();
		txtCountX.setText("0");
		txtCountX.setEditable(false);
		txtCountX.setHorizontalAlignment(SwingConstants.CENTER);
		txtCountX.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel_5.add(txtCountX, BorderLayout.CENTER);
		txtCountX.setColumns(10);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_6);
		panel_6.setLayout(new BorderLayout(0, 0));
		
		btn4 = new JButton("");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn4.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn4.setBackground(xColor);
				}else {
					btn4.setBackground(yColor);
				}
				choosePlayer();
				btn4.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn4.setBackground(Color.LIGHT_GRAY);
		btn4.setFocusable(false);
		btn4.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_6.add(btn4, BorderLayout.CENTER);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_7);
		panel_7.setLayout(new BorderLayout(0, 0));
		
		btn5 = new JButton("");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn5.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn5.setBackground(xColor);
				}else {
					btn5.setBackground(yColor);
				}
				choosePlayer();
				btn5.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn5.setBackground(Color.LIGHT_GRAY);
		btn5.setFocusable(false);
		btn5.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_7.add(btn5, BorderLayout.CENTER);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_8);
		panel_8.setLayout(new BorderLayout(0, 0));
		
		btn6 = new JButton("");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn6.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn6.setBackground(xColor);
				}else {
					btn6.setBackground(yColor);
				}
				choosePlayer();
				btn6.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn6.setBackground(Color.LIGHT_GRAY);
		btn6.setFocusable(false);
		btn6.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_8.add(btn6, BorderLayout.CENTER);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_9);
		panel_9.setLayout(new BorderLayout(0, 0));
		
		JLabel lblPlayerO = new JLabel("Player O Win");
		lblPlayerO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPlayerO.setHorizontalAlignment(SwingConstants.CENTER);
		panel_9.add(lblPlayerO, BorderLayout.CENTER);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_10);
		panel_10.setLayout(new BorderLayout(0, 0));
		
		txtCountO = new JTextField();
		txtCountO.setEditable(false);
		txtCountO.setHorizontalAlignment(SwingConstants.CENTER);
		txtCountO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtCountO.setText("0");
		panel_10.add(txtCountO, BorderLayout.CENTER);
		txtCountO.setColumns(10);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_11);
		panel_11.setLayout(new BorderLayout(0, 0));
		
		btn7 = new JButton("");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn7.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn7.setBackground(xColor);
				}else {
					btn7.setBackground(yColor);
				}
				choosePlayer();
				btn7.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn7.setBackground(Color.LIGHT_GRAY);
		btn7.setFocusable(false);
		btn7.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_11.add(btn7, BorderLayout.CENTER);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_12);
		panel_12.setLayout(new BorderLayout(0, 0));
		
		btn8 = new JButton("");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn8.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn8.setBackground(xColor);
				}else {
					btn8.setBackground(yColor);
				}
				choosePlayer();
				btn8.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn8.setBackground(Color.LIGHT_GRAY);
		btn8.setFocusable(false);
		btn8.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_12.add(btn8, BorderLayout.CENTER);
		
		JPanel panel_13 = new JPanel();
		panel_13.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_13);
		panel_13.setLayout(new BorderLayout(0, 0));
		
		btn9 = new JButton("");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn9.setText(startGame);
				if (startGame.equalsIgnoreCase("X")) {
					btn9.setBackground(xColor);
				}else {
					btn9.setBackground(yColor);
				}
				choosePlayer();
				btn9.setEnabled(false);
				winningGame();
				//checkDraw();
			}
		});
		btn9.setBackground(Color.LIGHT_GRAY);
		btn9.setFocusable(false);
		btn9.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panel_13.add(btn9, BorderLayout.CENTER);
		
		JPanel panel_14 = new JPanel();
		panel_14.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_14);
		panel_14.setLayout(new BorderLayout(0, 0));
		
		JButton btnReset = new JButton("Reset");
		btnReset.setForeground(Color.WHITE);
		btnReset.setBackground(Color.DARK_GRAY);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshAll();
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnReset.setFocusable(false);
		panel_14.add(btnReset, BorderLayout.CENTER);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_15);
		panel_15.setLayout(new BorderLayout(0, 0));
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(frame, "Confirm you want to Exit","Tic Tac Toe",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setForeground(Color.WHITE);
		btnExit.setFocusable(false);
		btnExit.setBackground(Color.DARK_GRAY);
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel_15.add(btnExit, BorderLayout.CENTER);
	}

}
